// File location: app/src/main/java/com/safeher/ai/presentation/MainActivity.kt

package com.safeher.ai.presentation

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import com.safeher.ai.application.EmergencyManager
import com.safeher.ai.application.SafeHerForegroundService
import com.safeher.ai.data.model.EmergencyState
import com.safeher.ai.databinding.ActivityMainBinding
import kotlinx.coroutines.launch

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var emergencyManager: EmergencyManager

    // Track whether we've already shown the accessibility prompt this session
    // so it doesn't re-appear every time the user comes back from Settings
    private var accessibilityPromptShownThisSession = false

    private val permissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { permissions ->
        val allGranted = permissions.values.all { it }
        if (allGranted) {
            startSafeHerService()
            checkBatteryOptimization()
        } else {
            Toast.makeText(this, "Permissions needed for SafeHer to protect you", Toast.LENGTH_LONG).show()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        emergencyManager = EmergencyManager.getInstance(applicationContext)

        setupButtons()
        observeEmergencyState()
        checkPermissionsAndStart()
    }

    override fun onResume() {
        super.onResume()
        // Only show accessibility prompt once per session, and only if the
        // system confirms it's genuinely not enabled. This prevents the popup
        // from firing again after the user returns from the Settings screen.
        if (!accessibilityPromptShownThisSession && !isAccessibilityServiceEnabled()) {
            accessibilityPromptShownThisSession = true
            checkAccessibilityService()
        }
    }

    // Checks the Android system directly rather than relying on the in-memory
    // flag, which resets whenever the app process restarts.
    private fun isAccessibilityServiceEnabled(): Boolean {
        val expectedComponent = "$packageName/.application.SafeHerAccessibilityService"
        val enabledServices = Settings.Secure.getString(
            contentResolver,
            Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
        ) ?: return false
        return enabledServices.contains(expectedComponent)
    }

    private fun setupButtons() {
        binding.btnSos.setOnClickListener {
            val state = EmergencyManager.state.value
            if (state !is EmergencyState.Active) {
                val intent = Intent(this, SafeHerForegroundService::class.java).apply {
                    action = SafeHerForegroundService.ACTION_TRIGGER_EMERGENCY
                }
                startService(intent)
            }
        }

        binding.btnSafe.setOnClickListener {
            startActivity(Intent(this, EmergencyActiveActivity::class.java))
        }

        binding.btnFakeCall.setOnClickListener {
            showFakeCallOptions()
        }

        binding.btnLog.setOnClickListener {
            startActivity(Intent(this, IncidentLogActivity::class.java))
        }

        binding.btnSettings.setOnClickListener {
            startActivity(Intent(this, SettingsActivity::class.java))
        }
    }

    private fun showFakeCallOptions() {
        val options = arrayOf("Call now", "In 1 minute", "In 2 minutes", "In 5 minutes", "In 10 minutes")
        val delays = arrayOf(0, 1, 2, 5, 10)
        AlertDialog.Builder(this)
            .setTitle("Fake Call")
            .setItems(options) { _, which ->
                val intent = Intent(this, FakeCallActivity::class.java).apply {
                    putExtra(FakeCallActivity.EXTRA_DELAY_MINUTES, delays[which])
                }
                startActivity(intent)
            }
            .show()
    }

    private fun observeEmergencyState() {
        lifecycleScope.launch {
            EmergencyManager.state.collect { state ->
                when (state) {
                    is EmergencyState.Idle -> {
                        binding.btnSos.text = "SOS"
                        binding.btnSos.setBackgroundColor(getColor(android.R.color.holo_red_dark))
                        binding.statusText.text = "You are protected"
                        binding.btnSafe.isEnabled = false
                        binding.btnSafe.text = "I Am Safe"
                    }
                    is EmergencyState.Active -> {
                        binding.btnSos.text = "EMERGENCY ACTIVE"
                        binding.btnSos.setBackgroundColor(getColor(android.R.color.holo_orange_dark))
                        binding.statusText.text = "🚨 Emergency in progress"
                        binding.btnSafe.isEnabled = true
                        binding.btnSafe.text = "I AM SAFE — TAP HERE"
                        startActivity(Intent(this@MainActivity, EmergencyActiveActivity::class.java))
                    }
                    is EmergencyState.Classifying -> {
                        binding.statusText.text = "Analysing incident..."
                        binding.btnSafe.isEnabled = false
                        binding.btnSos.text = "SOS"
                        binding.btnSos.setBackgroundColor(getColor(android.R.color.holo_red_dark))
                    }
                    is EmergencyState.Classified -> {
                        binding.statusText.text = "Last incident: ${state.session.classificationResult}"
                        binding.btnSafe.isEnabled = false
                        binding.btnSos.text = "SOS"
                        binding.btnSos.setBackgroundColor(getColor(android.R.color.holo_red_dark))
                    }
                }
            }
        }
    }

    // SR-NF5 — shown once per session only, after system check confirms it's off.
    // Message is softened for phones where the setting may not exist at all.
    private fun checkAccessibilityService() {
        AlertDialog.Builder(this)
            .setTitle("Enable Power Button Trigger")
            .setMessage(
                "To activate SafeHer by double-pressing the power button (even when the screen " +
                        "is off), please enable SafeHer in Accessibility Settings.\n\n" +
                        "Go to: Settings → Accessibility → SafeHer Emergency Trigger → Turn ON\n\n" +
                        "If you don't see it, your phone model may not support this. " +
                        "The SOS button and voice trigger will still work."
            )
            .setPositiveButton("Open Settings") { _, _ ->
                startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            }
            .setNegativeButton("Skip", null)
            .show()
    }

    private fun checkBatteryOptimization() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            val pm = getSystemService(PowerManager::class.java)
            if (!pm.isIgnoringBatteryOptimizations(packageName)) {
                AlertDialog.Builder(this)
                    .setTitle("Important: Battery Settings")
                    .setMessage(
                        "SafeHer needs to run in the background to protect you. " +
                                "Battery optimization may stop the app working when screen is off.\n\n" +
                                "Tap 'Fix Now' and select 'Don't optimize'."
                    )
                    .setPositiveButton("Fix Now") { _, _ ->
                        val intent = Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS).apply {
                            data = Uri.parse("package:$packageName")
                        }
                        startActivity(intent)
                    }
                    .setNegativeButton("Later", null)
                    .show()
            }
        }
    }

    private fun checkPermissionsAndStart() {
        val needed = mutableListOf<String>()
        val required = listOf(
            Manifest.permission.ACCESS_FINE_LOCATION,
            Manifest.permission.RECORD_AUDIO,
            Manifest.permission.CAMERA,
            Manifest.permission.SEND_SMS
        )
        required.forEach { perm ->
            if (ContextCompat.checkSelfPermission(this, perm) != PackageManager.PERMISSION_GRANTED) {
                needed.add(perm)
            }
        }
        if (needed.isEmpty()) {
            startSafeHerService()
            checkBatteryOptimization()
        } else {
            permissionLauncher.launch(needed.toTypedArray())
        }
    }

    private fun startSafeHerService() {
        if (!SafeHerForegroundService.isRunning) {
            val intent = Intent(this, SafeHerForegroundService::class.java).apply {
                action = SafeHerForegroundService.ACTION_START
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                startForegroundService(intent)
            } else {
                startService(intent)
            }
        }
    }
}