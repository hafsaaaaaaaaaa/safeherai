// File location: app/src/main/java/com/safeher/ai/presentation/IncidentLogActivity.kt

package com.safeher.ai.presentation

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.safeher.ai.R
import com.safeher.ai.data.IncidentRepository
import com.safeher.ai.data.model.ClassificationResult
import com.safeher.ai.data.model.EmergencySession
import com.safeher.ai.data.model.TriggerSource
import com.safeher.ai.databinding.ActivityIncidentLogBinding
import kotlinx.coroutines.launch
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class IncidentLogActivity : AppCompatActivity() {

    private lateinit var binding: ActivityIncidentLogBinding
    private lateinit var repository: IncidentRepository

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityIncidentLogBinding.inflate(layoutInflater)
        setContentView(binding.root)

        supportActionBar?.hide()

        binding.btnBack.setOnClickListener { finish() }

        repository = IncidentRepository(this)
        binding.recyclerView.layoutManager = LinearLayoutManager(this)
        loadIncidents()
    }

    private fun loadIncidents() {
        lifecycleScope.launch {
            val incidents = repository.getAllIncidents()
            if (incidents.isEmpty()) {
                binding.emptyText.visibility = View.VISIBLE
                binding.recyclerView.visibility = View.GONE
            } else {
                binding.emptyText.visibility = View.GONE
                binding.recyclerView.visibility = View.VISIBLE
                binding.recyclerView.adapter = IncidentAdapter(incidents)
            }
        }
    }
}

class IncidentAdapter(private val incidents: List<EmergencySession>) :
    RecyclerView.Adapter<IncidentAdapter.ViewHolder>() {

    class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val tvDate: TextView = view.findViewById(R.id.tvDate)
        val tvDuration: TextView = view.findViewById(R.id.tvDuration)
        val tvClassification: TextView = view.findViewById(R.id.tvClassification)
        val tvExplanation: TextView = view.findViewById(R.id.tvExplanation)
        val tvTrigger: TextView = view.findViewById(R.id.tvTrigger)
        val tvRecording: TextView = view.findViewById(R.id.tvRecording)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_incident, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val incident = incidents[position]
        val dateFormat = SimpleDateFormat("dd MMM yyyy, HH:mm", Locale.getDefault())

        holder.tvDate.text = dateFormat.format(Date(incident.triggeredAt))
        holder.tvDuration.text = "Duration: ${incident.durationSeconds}s"

        // Fix trigger source display — show friendly name
        holder.tvTrigger.text = "Trigger: " + when (incident.triggerSource) {
            TriggerSource.POWER_BUTTON -> "Power Button"
            TriggerSource.VOICE_TRIGGER -> "Voice Phrase"
            TriggerSource.MANUAL -> "SOS Button"
        }

        // Recording status
        if (incident.recordingPath != null) {
            val file = File(incident.recordingPath)
            if (file.exists()) {
                val sizeKb = file.length() / 1024
                holder.tvRecording.text = "🎙 Recording: ${sizeKb}KB saved securely"
            } else {
                holder.tvRecording.text = "🎙 Recording: saved (auto-deleted after 72h)"
            }
        } else {
            holder.tvRecording.text = "🎙 No recording captured"
        }

        val classification = incident.classificationResult
        holder.tvClassification.text = when (classification) {
            ClassificationResult.UNSAFE -> "⚠️ UNSAFE"
            ClassificationResult.INCONCLUSIVE -> "❓ INCONCLUSIVE"
            ClassificationResult.SAFE -> "✅ SAFE"
            ClassificationResult.UNCLASSIFIED -> "⏳ CLASSIFYING..."
            null -> "⏳ PENDING"
        }

        holder.tvClassification.setTextColor(
            when (classification) {
                ClassificationResult.UNSAFE -> 0xFFD32F2F.toInt()
                ClassificationResult.INCONCLUSIVE -> 0xFFF57C00.toInt()
                ClassificationResult.SAFE -> 0xFF388E3C.toInt()
                else -> 0xFFAAAAAA.toInt()
            }
        )

        holder.tvExplanation.text = incident.classificationExplanation
            ?: "Classification in progress..."
    }

    override fun getItemCount() = incidents.size
}