// File location: app/src/main/java/com/safeher/ai/presentation/SettingsActivity.kt

package com.safeher.ai.presentation

import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.safeher.ai.databinding.ActivitySettingsBinding

class SettingsActivity : AppCompatActivity() {

    private lateinit var binding: ActivitySettingsBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivitySettingsBinding.inflate(layoutInflater)
        setContentView(binding.root)

        supportActionBar?.title = "Settings"
        supportActionBar?.setDisplayHomeAsUpEnabled(true)

        val prefs = getSharedPreferences("safeher_prefs", MODE_PRIVATE)

        // Load current values
        binding.etTriggerPhrase.setText(prefs.getString("trigger_phrase", ""))
        binding.etFakeCallerName.setText(prefs.getString("fake_caller_name", "Mom"))
        binding.etAuthorityName.setText(prefs.getString("authority_contact_name", ""))
        binding.etAuthorityPhone.setText(prefs.getString("authority_contact_phone", ""))
        binding.switchRiskAlerts.isChecked = prefs.getBoolean("risk_alerts_enabled", true)

        binding.btnManageContacts.setOnClickListener {
            startActivity(Intent(this, ContactsActivity::class.java))
        }

        binding.btnSaveSettings.setOnClickListener {
            val triggerPhrase = binding.etTriggerPhrase.text.toString().trim()
            val fakeCallerName = binding.etFakeCallerName.text.toString().trim()
            val authorityName = binding.etAuthorityName.text.toString().trim()
            val authorityPhone = binding.etAuthorityPhone.text.toString().trim()

            if (triggerPhrase.length < 3) {
                binding.etTriggerPhrase.error = "Phrase must be at least 3 characters"
                return@setOnClickListener
            }

            prefs.edit()
                .putString("trigger_phrase", triggerPhrase)
                .putString("fake_caller_name", fakeCallerName.ifEmpty { "Mom" })
                .putString("authority_contact_name", authorityName)
                .putString("authority_contact_phone", authorityPhone)
                .putBoolean("risk_alerts_enabled", binding.switchRiskAlerts.isChecked)
                .apply()

            Toast.makeText(this, "Settings saved", Toast.LENGTH_SHORT).show()
        }
    }

    override fun onSupportNavigateUp(): Boolean {
        finish()
        return true
    }
}