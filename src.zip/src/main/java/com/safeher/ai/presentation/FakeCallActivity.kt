// File location: app/src/main/java/com/safeher/ai/presentation/FakeCallActivity.kt

package com.safeher.ai.presentation

import android.media.Ringtone
import android.media.RingtoneManager
import android.os.Build
import android.os.Bundle
import android.os.CountDownTimer
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.view.View
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.safeher.ai.databinding.ActivityFakeCallBinding

class FakeCallActivity : AppCompatActivity() {

    private lateinit var binding: ActivityFakeCallBinding
    private var ringtone: Ringtone? = null
    private var vibrator: Vibrator? = null
    private var countDownTimer: CountDownTimer? = null

    companion object {
        const val EXTRA_DELAY_MINUTES = "delay_minutes"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityFakeCallBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val callerName = getSharedPreferences("safeher_prefs", MODE_PRIVATE)
            .getString("fake_caller_name", "Mom") ?: "Mom"

        val delayMinutes = intent.getIntExtra(EXTRA_DELAY_MINUTES, 0)

        if (delayMinutes > 0) {
            // Scheduled mode — show countdown per UR-F5
            showScheduledMode(callerName, delayMinutes)
        } else {
            // Immediate mode
            showIncomingCall(callerName)
        }
    }

    private fun showScheduledMode(callerName: String, delayMinutes: Int) {
        binding.incomingLayout.visibility = View.GONE
        binding.activeCallLayout.visibility = View.GONE
        binding.scheduledLayout.visibility = View.VISIBLE

        binding.tvScheduledCallerName.text = callerName
        binding.tvScheduledMessage.text = "Fake call from $callerName will ring in $delayMinutes minute(s)"

        val delayMs = delayMinutes * 60 * 1000L

        countDownTimer = object : CountDownTimer(delayMs, 1000) {
            override fun onTick(millisUntilFinished: Long) {
                val seconds = millisUntilFinished / 1000
                val mins = seconds / 60
                val secs = seconds % 60
                binding.tvCountdown.text = String.format("%d:%02d", mins, secs)
            }

            override fun onFinish() {
                binding.scheduledLayout.visibility = View.GONE
                showIncomingCall(callerName)
            }
        }.start()

        binding.btnCancelScheduled.setOnClickListener {
            countDownTimer?.cancel()
            finish()
        }
    }

    private fun showIncomingCall(callerName: String) {
        binding.incomingLayout.visibility = View.VISIBLE
        binding.callerName.text = callerName
        binding.callerNumber.text = "Mobile"

        startRinging()

        binding.btnAnswer.setOnClickListener {
            stopRinging()
            binding.incomingLayout.visibility = View.GONE
            binding.activeCallLayout.visibility = View.VISIBLE
        }

        binding.btnDecline.setOnClickListener {
            stopRinging()
            finish()
        }

        binding.btnEndCall.setOnClickListener {
            finish()
        }
    }

    private fun startRinging() {
        vibrator = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            val vm = getSystemService(VIBRATOR_MANAGER_SERVICE) as VibratorManager
            vm.defaultVibrator
        } else {
            @Suppress("DEPRECATION")
            getSystemService(VIBRATOR_SERVICE) as Vibrator
        }

        val pattern = longArrayOf(0, 500, 500, 500, 500, 500)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            vibrator?.vibrate(VibrationEffect.createWaveform(pattern, 0))
        } else {
            @Suppress("DEPRECATION")
            vibrator?.vibrate(pattern, 0)
        }

        val uri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_RINGTONE)
        ringtone = RingtoneManager.getRingtone(applicationContext, uri)
        ringtone?.play()
    }

    private fun stopRinging() {
        ringtone?.stop()
        vibrator?.cancel()
    }

    override fun onDestroy() {
        super.onDestroy()
        stopRinging()
        countDownTimer?.cancel()
    }
}