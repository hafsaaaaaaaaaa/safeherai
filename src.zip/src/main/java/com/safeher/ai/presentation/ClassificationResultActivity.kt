// File location: app/src/main/java/com/safeher/ai/presentation/ClassificationResultActivity.kt

package com.safeher.ai.presentation

import android.content.Intent
import android.os.Bundle
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.safeher.ai.application.EmergencyManager
import com.safeher.ai.data.model.ClassificationResult
import com.safeher.ai.data.model.EmergencyState
import com.safeher.ai.databinding.ActivityClassificationResultBinding
import kotlinx.coroutines.launch

class ClassificationResultActivity : AppCompatActivity() {

    private lateinit var binding: ActivityClassificationResultBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityClassificationResultBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Get the classified session
        lifecycleScope.launch {
            EmergencyManager.state.collect { state ->
                if (state is EmergencyState.Classified) {
                    displayResult(state)
                }
            }
        }

        binding.btnBackHome.setOnClickListener {
            startActivity(Intent(this, MainActivity::class.java))
            finish()
        }

        binding.btnSubmitAuthority.setOnClickListener {
            startActivity(Intent(this, AuthoritySubmissionActivity::class.java))
        }
    }

    private fun displayResult(state: EmergencyState.Classified) {
        val session = state.session
        val result = session.classificationResult

        // Set classification label and color
        when (result) {
            ClassificationResult.UNSAFE -> {
                binding.tvClassificationLabel.text = "⚠️ UNSAFE"
                binding.tvClassificationLabel.setTextColor(0xFFD32F2F.toInt())
                binding.cardResult.setCardBackgroundColor(0xFF3D0000.toInt())
                // Show authority submission button per SR-F9
                binding.btnSubmitAuthority.visibility = View.VISIBLE
                binding.tvSubmitNote.visibility = View.VISIBLE
            }
            ClassificationResult.INCONCLUSIVE -> {
                binding.tvClassificationLabel.text = "❓ INCONCLUSIVE"
                binding.tvClassificationLabel.setTextColor(0xFFF57C00.toInt())
                binding.cardResult.setCardBackgroundColor(0xFF3D2000.toInt())
                binding.btnSubmitAuthority.visibility = View.GONE
                binding.tvSubmitNote.visibility = View.GONE
            }
            ClassificationResult.SAFE -> {
                binding.tvClassificationLabel.text = "✅ SAFE"
                binding.tvClassificationLabel.setTextColor(0xFF388E3C.toInt())
                binding.cardResult.setCardBackgroundColor(0xFF003D00.toInt())
                binding.btnSubmitAuthority.visibility = View.GONE
                binding.tvSubmitNote.visibility = View.GONE
            }
            else -> {
                binding.tvClassificationLabel.text = "⏳ CLASSIFYING..."
                binding.btnSubmitAuthority.visibility = View.GONE
                binding.tvSubmitNote.visibility = View.GONE
            }
        }

        // Show plain language explanation per SR-NF9
        binding.tvExplanation.text = session.classificationExplanation
            ?: "Classification in progress..."

        // Show duration
        binding.tvDuration.text = "Duration: ${session.durationSeconds} seconds"

        // Show trigger method
        binding.tvTrigger.text = "Triggered via: ${session.triggerSource.name.replace("_", " ")}"

        // Auto-delete notice per SR-NF10
        binding.tvAutoDelete.text = when (result) {
            ClassificationResult.UNSAFE -> "Recording kept until you submit or delete it."
            else -> "Recording will be automatically deleted after 72 hours."
        }
    }
}