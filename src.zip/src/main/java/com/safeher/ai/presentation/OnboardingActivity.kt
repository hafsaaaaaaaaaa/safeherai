// File location: app/src/main/java/com/safeher/ai/presentation/OnboardingActivity.kt

package com.safeher.ai.presentation

import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.safeher.ai.application.ContactsHelper
import com.safeher.ai.data.model.EmergencyContact
import com.safeher.ai.databinding.ActivityOnboardingBinding

class OnboardingActivity : AppCompatActivity() {

    private lateinit var binding: ActivityOnboardingBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityOnboardingBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.btnSave.setOnClickListener {
            val name = binding.etName.text.toString().trim()
            val triggerPhrase = binding.etTriggerPhrase.text.toString().trim()
            val contactName = binding.etContactName.text.toString().trim()
            val contactPhone = binding.etContactPhone.text.toString().trim()
            val callerName = binding.etFakeCallerName.text.toString().trim()
            val authorityName = binding.etAuthorityName.text.toString().trim()
            val authorityPhone = binding.etAuthorityPhone.text.toString().trim()

            // Validate required fields
            if (name.isEmpty()) {
                binding.etName.error = "Please enter your name"
                return@setOnClickListener
            }
            if (triggerPhrase.length < 3) {
                binding.etTriggerPhrase.error = "Phrase must be at least 3 characters"
                return@setOnClickListener
            }
            if (contactPhone.isEmpty()) {
                binding.etContactPhone.error = "Please add at least one emergency contact"
                return@setOnClickListener
            }

            // Save all settings per SR-F12
            val prefs = getSharedPreferences("safeher_prefs", MODE_PRIVATE)
            prefs.edit()
                .putString("user_name", name)
                .putString("trigger_phrase", triggerPhrase)
                .putString("fake_caller_name", callerName.ifEmpty { "Mom" })
                .putString("authority_contact_name", authorityName)
                .putString("authority_contact_phone", authorityPhone)
                .putBoolean("risk_alerts_enabled", true)
                .putBoolean("onboarding_complete", true)
                .apply()

            // Save emergency contact
            val contact = EmergencyContact(
                id = System.currentTimeMillis(),
                name = contactName.ifEmpty { "Emergency Contact" },
                phone = contactPhone
            )
            ContactsHelper.saveEmergencyContacts(this, listOf(contact))

            Toast.makeText(this, "Setup complete! You are now protected.", Toast.LENGTH_SHORT).show()
            startActivity(Intent(this, MainActivity::class.java))
            finish()
        }
    }
}