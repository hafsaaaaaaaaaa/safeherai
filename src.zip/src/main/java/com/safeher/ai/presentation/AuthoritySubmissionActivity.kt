// File location: app/src/main/java/com/safeher/ai/presentation/AuthoritySubmissionActivity.kt

package com.safeher.ai.presentation

import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.safeher.ai.application.EmergencyManager
import com.safeher.ai.data.IncidentRepository
import com.safeher.ai.data.model.EmergencyState
import com.safeher.ai.databinding.ActivityAuthoritySubmissionBinding
import kotlinx.coroutines.launch

class AuthoritySubmissionActivity : AppCompatActivity() {

    private lateinit var binding: ActivityAuthoritySubmissionBinding
    private lateinit var repository: IncidentRepository

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityAuthoritySubmissionBinding.inflate(layoutInflater)
        setContentView(binding.root)

        repository = IncidentRepository(this)

        supportActionBar?.title = "Submit to Authority"
        supportActionBar?.setDisplayHomeAsUpEnabled(true)

        // Load authority contact from prefs
        val prefs = getSharedPreferences("safeher_prefs", MODE_PRIVATE)
        val authorityName = prefs.getString("authority_contact_name", "") ?: ""
        val authorityPhone = prefs.getString("authority_contact_phone", "") ?: ""

        if (authorityName.isEmpty() && authorityPhone.isEmpty()) {
            binding.tvAuthorityContact.text = "No authority contact configured.\nPlease add one in Settings."
            binding.btnConfirmSubmit.isEnabled = false
        } else {
            binding.tvAuthorityContact.text = "Will be submitted to:\n$authorityName\n$authorityPhone"
            binding.btnConfirmSubmit.isEnabled = true
        }

        // Get current classified session
        val state = EmergencyManager.state.value
        if (state is EmergencyState.Classified) {
            val session = state.session
            binding.tvIncidentSummary.text = """
                Incident Summary:
                Date: ${java.text.SimpleDateFormat("dd MMM yyyy HH:mm", java.util.Locale.getDefault()).format(java.util.Date(session.triggeredAt))}
                Duration: ${session.durationSeconds} seconds
                Classification: ${session.classificationResult?.name}
                Confidence: ${String.format("%.0f", (session.classificationScore * 100))}%
            """.trimIndent()
        }

        binding.btnConfirmSubmit.setOnClickListener {
            submitToAuthority()
        }

        binding.btnCancel.setOnClickListener {
            finish()
        }
    }

    private fun submitToAuthority() {
        binding.progressBar.visibility = View.VISIBLE
        binding.btnConfirmSubmit.isEnabled = false

        lifecycleScope.launch {
            try {
                val prefs = getSharedPreferences("safeher_prefs", MODE_PRIVATE)
                val authorityPhone = prefs.getString("authority_contact_phone", "") ?: ""
                val userName = prefs.getString("user_name", "SafeHer User") ?: "SafeHer User"

                val state = EmergencyManager.state.value
                if (state is EmergencyState.Classified) {
                    val session = state.session

                    // Send SMS to authority — per SR-F9 user never receives recording directly
                    val message = """
                        🚨 SafeHer Incident Report
                        User: $userName
                        Classification: ${session.classificationResult?.name}
                        Date: ${java.util.Date(session.triggeredAt)}
                        Duration: ${session.durationSeconds}s
                        Location: https://maps.google.com/?q=${session.startLatitude},${session.startLongitude}
                        Confidence: ${String.format("%.0f", session.classificationScore * 100)}%
                    """.trimIndent()

                    // Send via SMS
                    val smsManager = getSystemService(android.telephony.SmsManager::class.java)
                    // Split long message if needed
                    val parts = smsManager.divideMessage(message)
                    smsManager.sendMultipartTextMessage(authorityPhone, null, parts, null, null)

                    // Mark as submitted in repository
                    repository.markAsSubmitted(session.id)

                    binding.progressBar.visibility = View.GONE
                    binding.tvSubmitSuccess.visibility = View.VISIBLE
                    binding.btnConfirmSubmit.visibility = View.GONE

                    Toast.makeText(this@AuthoritySubmissionActivity,
                        "Incident submitted successfully. This is permanently logged.",
                        Toast.LENGTH_LONG).show()
                }
            } catch (e: Exception) {
                binding.progressBar.visibility = View.GONE
                binding.btnConfirmSubmit.isEnabled = true
                Toast.makeText(this@AuthoritySubmissionActivity,
                    "Submission failed: ${e.message}",
                    Toast.LENGTH_LONG).show()
            }
        }
    }

    override fun onSupportNavigateUp(): Boolean {
        finish()
        return true
    }
}