// File location: app/src/main/java/com/safeher/ai/presentation/EmergencyActiveActivity.kt

package com.safeher.ai.presentation

import android.content.Intent
import android.os.Bundle
import android.os.SystemClock
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.safeher.ai.application.BiometricHelper
import com.safeher.ai.application.EmergencyManager
import com.safeher.ai.data.model.DeactivationMethod
import com.safeher.ai.data.model.EmergencyState
import com.safeher.ai.databinding.ActivityEmergencyActiveBinding
import kotlinx.coroutines.launch

class EmergencyActiveActivity : AppCompatActivity() {

    private lateinit var binding: ActivityEmergencyActiveBinding
    private lateinit var emergencyManager: EmergencyManager
    private var failedAttempts = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityEmergencyActiveBinding.inflate(layoutInflater)
        setContentView(binding.root)

        emergencyManager = EmergencyManager.getInstance(applicationContext)

        // Start chronometer to show how long emergency has been active
        binding.chronometer.base = SystemClock.elapsedRealtime()
        binding.chronometer.start()

        // Observe state — if emergency ends navigate back
        lifecycleScope.launch {
            EmergencyManager.state.collect { state ->
                when (state) {
                    is EmergencyState.Idle,
                    is EmergencyState.Classifying,
                    is EmergencyState.Classified -> {
                        // Emergency ended — go to classification result
                        if (state is EmergencyState.Classified) {
                            val intent = Intent(this@EmergencyActiveActivity, ClassificationResultActivity::class.java)
                            startActivity(intent)
                        }
                        finish()
                    }
                    else -> {}
                }
            }
        }

        // I Am Safe button — requires PIN/fingerprint per UC-05
        binding.btnIAmSafe.setOnClickListener {
            BiometricHelper(
                activity = this,
                onSuccess = {
                    lifecycleScope.launch {
                        failedAttempts = 0
                        emergencyManager.deactivate(DeactivationMethod.CALM_PIN)
                    }
                },
                onFailure = {
                    failedAttempts++
                    // Per UC-05 alternate flow 4a — after 2 failed attempts send extra alert
                    if (failedAttempts >= 2) {
                        emergencyManager.notifyFailedDeactivation()
                        Toast.makeText(
                            this,
                            "Failed attempts detected. Contacts have been alerted.",
                            Toast.LENGTH_LONG
                        ).show()
                        failedAttempts = 0
                    } else {
                        Toast.makeText(
                            this,
                            "Authentication failed. Try again.",
                            Toast.LENGTH_SHORT
                        ).show()
                    }
                }
            ).authenticate()
        }
    }

    // Prevent back button during emergency per SRS
    override fun onBackPressed() {
        Toast.makeText(this, "Cannot exit during emergency. Tap 'I Am Safe' to deactivate.", Toast.LENGTH_SHORT).show()
    }

    override fun onDestroy() {
        super.onDestroy()
        binding.chronometer.stop()
    }
}