// File location: app/src/main/java/com/safeher/ai/presentation/SplashActivity.kt

package com.safeher.ai.presentation

import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import androidx.appcompat.app.AppCompatActivity

class SplashActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Small delay so the app has time to initialize
        Handler(Looper.getMainLooper()).postDelayed({
            val prefs = getSharedPreferences("safeher_prefs", MODE_PRIVATE)
            val onboardingComplete = prefs.getBoolean("onboarding_complete", false)

            if (onboardingComplete) {
                startActivity(Intent(this, MainActivity::class.java))
            } else {
                startActivity(Intent(this, OnboardingActivity::class.java))
            }
            finish()
        }, 500)
    }
}