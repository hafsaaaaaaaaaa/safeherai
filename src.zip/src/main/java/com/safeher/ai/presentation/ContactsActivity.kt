// File location: app/src/main/java/com/safeher/ai/presentation/ContactsActivity.kt

package com.safeher.ai.presentation

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.textfield.TextInputEditText
import com.safeher.ai.R
import com.safeher.ai.application.ContactsHelper
import com.safeher.ai.data.model.EmergencyContact
import com.safeher.ai.databinding.ActivityContactsBinding

class ContactsActivity : AppCompatActivity() {

    private lateinit var binding: ActivityContactsBinding
    private var contacts = mutableListOf<EmergencyContact>()
    private lateinit var adapter: ContactsAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityContactsBinding.inflate(layoutInflater)
        setContentView(binding.root)

        supportActionBar?.title = "Emergency Contacts"
        supportActionBar?.setDisplayHomeAsUpEnabled(true)

        contacts = ContactsHelper.getEmergencyContacts(this).toMutableList()
        adapter = ContactsAdapter(contacts,
            onEdit = { contact -> showEditDialog(contact) },
            onDelete = { contact -> confirmDelete(contact) }
        )

        binding.recyclerContacts.layoutManager = LinearLayoutManager(this)
        binding.recyclerContacts.adapter = adapter

        updateEmptyState()

        binding.btnAddContact.setOnClickListener {
            showAddDialog()
        }
    }

    private fun showAddDialog() {
        val dialogView = layoutInflater.inflate(R.layout.dialog_add_contact, null)
        val etName = dialogView.findViewById<TextInputEditText>(R.id.etContactName)
        val etPhone = dialogView.findViewById<TextInputEditText>(R.id.etContactPhone)

        AlertDialog.Builder(this)
            .setTitle("Add Emergency Contact")
            .setView(dialogView)
            .setPositiveButton("Add") { _, _ ->
                val name = etName.text.toString().trim()
                val phone = etPhone.text.toString().trim()
                if (name.isEmpty() || phone.isEmpty()) {
                    Toast.makeText(this, "Please fill in both fields", Toast.LENGTH_SHORT).show()
                    return@setPositiveButton
                }
                if (contacts.size >= 5) {
                    Toast.makeText(this, "Maximum 5 contacts allowed", Toast.LENGTH_SHORT).show()
                    return@setPositiveButton
                }
                val contact = EmergencyContact(
                    id = System.currentTimeMillis(),
                    name = name,
                    phone = phone
                )
                contacts.add(contact)
                saveAndRefresh()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun showEditDialog(contact: EmergencyContact) {
        val dialogView = layoutInflater.inflate(R.layout.dialog_add_contact, null)
        val etName = dialogView.findViewById<TextInputEditText>(R.id.etContactName)
        val etPhone = dialogView.findViewById<TextInputEditText>(R.id.etContactPhone)

        etName.setText(contact.name)
        etPhone.setText(contact.phone)

        AlertDialog.Builder(this)
            .setTitle("Edit Contact")
            .setView(dialogView)
            .setPositiveButton("Save") { _, _ ->
                val name = etName.text.toString().trim()
                val phone = etPhone.text.toString().trim()
                if (name.isEmpty() || phone.isEmpty()) {
                    Toast.makeText(this, "Please fill in both fields", Toast.LENGTH_SHORT).show()
                    return@setPositiveButton
                }
                val index = contacts.indexOfFirst { it.id == contact.id }
                if (index != -1) {
                    contacts[index] = contact.copy(name = name, phone = phone)
                    saveAndRefresh()
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun confirmDelete(contact: EmergencyContact) {
        AlertDialog.Builder(this)
            .setTitle("Remove Contact")
            .setMessage("Remove ${contact.name} from emergency contacts?")
            .setPositiveButton("Remove") { _, _ ->
                contacts.removeAll { it.id == contact.id }
                saveAndRefresh()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun saveAndRefresh() {
        ContactsHelper.saveEmergencyContacts(this, contacts)
        adapter.notifyDataSetChanged()
        updateEmptyState()
        Toast.makeText(this, "Contacts updated", Toast.LENGTH_SHORT).show()
    }

    private fun updateEmptyState() {
        if (contacts.isEmpty()) {
            binding.tvEmpty.visibility = View.VISIBLE
            binding.recyclerContacts.visibility = View.GONE
        } else {
            binding.tvEmpty.visibility = View.GONE
            binding.recyclerContacts.visibility = View.VISIBLE
        }
    }

    override fun onSupportNavigateUp(): Boolean {
        finish()
        return true
    }
}

class ContactsAdapter(
    private val contacts: List<EmergencyContact>,
    private val onEdit: (EmergencyContact) -> Unit,
    private val onDelete: (EmergencyContact) -> Unit
) : RecyclerView.Adapter<ContactsAdapter.ViewHolder>() {

    class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val tvName: TextView = view.findViewById(R.id.tvContactName)
        val tvPhone: TextView = view.findViewById(R.id.tvContactPhone)
        val btnEdit: Button = view.findViewById(R.id.btnEdit)
        val btnDelete: Button = view.findViewById(R.id.btnDelete)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_contact, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val contact = contacts[position]
        holder.tvName.text = contact.name
        holder.tvPhone.text = contact.phone
        holder.btnEdit.setOnClickListener { onEdit(contact) }
        holder.btnDelete.setOnClickListener { onDelete(contact) }
    }

    override fun getItemCount() = contacts.size
}