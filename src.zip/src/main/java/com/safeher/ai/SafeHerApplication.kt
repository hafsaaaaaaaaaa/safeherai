// File location: app/src/main/java/com/safeher/ai/SafeHerApplication.kt

package com.safeher.ai

import android.app.Application
import android.app.NotificationChannel
import android.app.NotificationManager
import android.os.Build

class SafeHerApplication : Application() {

    companion object {
        const val CHANNEL_FOREGROUND = "safeher_foreground"
        const val CHANNEL_RISK_ALERT = "safeher_risk_alert"
        const val CHANNEL_EMERGENCY  = "safeher_emergency"

        lateinit var instance: SafeHerApplication
            private set
    }

    override fun onCreate() {
        super.onCreate()
        instance = this
        createNotificationChannels()
    }

    private fun createNotificationChannels() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val nm = getSystemService(NotificationManager::class.java)

            nm.createNotificationChannel(
                NotificationChannel(
                    CHANNEL_FOREGROUND,
                    "SafeHer Active",
                    NotificationManager.IMPORTANCE_LOW
                ).apply {
                    description = "Keeps SafeHer running in the background"
                    setShowBadge(false)
                }
            )

            nm.createNotificationChannel(
                NotificationChannel(
                    CHANNEL_RISK_ALERT,
                    "Safety Alerts",
                    NotificationManager.IMPORTANCE_DEFAULT
                ).apply {
                    lockscreenVisibility = android.app.Notification.VISIBILITY_PRIVATE
                    enableVibration(true)
                    vibrationPattern = longArrayOf(0, 150, 100, 150, 100, 150)
                    setShowBadge(false)
                }
            )

            nm.createNotificationChannel(
                NotificationChannel(
                    CHANNEL_EMERGENCY,
                    "Emergency Active",
                    NotificationManager.IMPORTANCE_HIGH
                ).apply {
                    lockscreenVisibility = android.app.Notification.VISIBILITY_PRIVATE
                    setShowBadge(true)
                }
            )
        }
    }
}