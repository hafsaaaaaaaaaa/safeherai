// File location: app/src/main/java/com/safeher/ai/data/IncidentRepository.kt

package com.safeher.ai.data

import android.content.Context
import android.util.Log
import com.safeher.ai.data.model.ClassificationResult
import com.safeher.ai.data.model.EmergencySession
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class IncidentRepository(private val context: Context) {

    companion object {
        private const val TAG = "IncidentRepository"
    }

    private val prefs = context.getSharedPreferences("safeher_incidents", Context.MODE_PRIVATE)

    suspend fun saveIncident(session: EmergencySession): Long {
        return withContext(Dispatchers.IO) {
            try {
                val id = System.currentTimeMillis()
                val json = sessionToJson(session.copy(id = id))
                val existing = prefs.getString("incidents", "[]") ?: "[]"
                val array = org.json.JSONArray(existing)
                array.put(org.json.JSONObject(json))
                prefs.edit().putString("incidents", array.toString()).apply()
                Log.d(TAG, "Incident saved: $id")
                id
            } catch (e: Exception) {
                Log.e(TAG, "Failed to save incident: ${e.message}")
                -1L
            }
        }
    }

    suspend fun getAllIncidents(): List<EmergencySession> {
        return withContext(Dispatchers.IO) {
            try {
                val json = prefs.getString("incidents", "[]") ?: "[]"
                val array = org.json.JSONArray(json)
                (0 until array.length()).map { i ->
                    jsonToSession(array.getJSONObject(i).toString())
                }.sortedByDescending { it.triggeredAt }
            } catch (e: Exception) {
                Log.e(TAG, "Failed to get incidents: ${e.message}")
                emptyList()
            }
        }
    }

    suspend fun updateClassification(
        id: Long,
        result: ClassificationResult,
        score: Float,
        explanation: String
    ) {
        withContext(Dispatchers.IO) {
            try {
                val json = prefs.getString("incidents", "[]") ?: "[]"
                val array = org.json.JSONArray(json)
                for (i in 0 until array.length()) {
                    val obj = array.getJSONObject(i)
                    if (obj.getLong("id") == id) {
                        obj.put("classificationResult", result.name)
                        obj.put("classificationScore", score)
                        obj.put("classificationExplanation", explanation)
                        break
                    }
                }
                prefs.edit().putString("incidents", array.toString()).apply()
            } catch (e: Exception) {
                Log.e(TAG, "Failed to update classification: ${e.message}")
            }
        }
    }

    suspend fun markAsSubmitted(id: Long) {
        withContext(Dispatchers.IO) {
            try {
                val json = prefs.getString("incidents", "[]") ?: "[]"
                val array = org.json.JSONArray(json)
                for (i in 0 until array.length()) {
                    val obj = array.getJSONObject(i)
                    if (obj.getLong("id") == id) {
                        obj.put("authoritySubmitted", true)
                        obj.put("authoritySubmittedAt", System.currentTimeMillis())
                        break
                    }
                }
                prefs.edit().putString("incidents", array.toString()).apply()
                Log.d(TAG, "Incident $id marked as submitted")
            } catch (e: Exception) {
                Log.e(TAG, "Failed to mark as submitted: ${e.message}")
            }
        }
    }

    suspend fun deleteExpiredIncidents() {
        withContext(Dispatchers.IO) {
            try {
                val now = System.currentTimeMillis()
                val cutoff = now - (72 * 60 * 60 * 1000L)
                val json = prefs.getString("incidents", "[]") ?: "[]"
                val array = org.json.JSONArray(json)
                val filtered = org.json.JSONArray()
                for (i in 0 until array.length()) {
                    val obj = array.getJSONObject(i)
                    val triggeredAt = obj.getLong("triggeredAt")
                    val classification = obj.optString("classificationResult", "")
                    if (classification == ClassificationResult.UNSAFE.name || triggeredAt > cutoff) {
                        filtered.put(obj)
                    }
                }
                prefs.edit().putString("incidents", filtered.toString()).apply()
            } catch (e: Exception) {
                Log.e(TAG, "Failed to delete expired: ${e.message}")
            }
        }
    }

    private fun sessionToJson(session: EmergencySession): String {
        return org.json.JSONObject().apply {
            put("id", session.id)
            put("triggeredAt", session.triggeredAt)
            put("triggerSource", session.triggerSource.name)
            put("startLatitude", session.startLatitude)
            put("startLongitude", session.startLongitude)
            put("locationApproximate", session.locationApproximate)
            put("deactivatedAt", session.deactivatedAt ?: 0)
            put("deactivationMethod", session.deactivationMethod?.name ?: "")
            put("durationSeconds", session.durationSeconds)
            put("classificationResult", session.classificationResult?.name ?: "")
            put("classificationScore", session.classificationScore)
            put("classificationExplanation", session.classificationExplanation ?: "")
            put("authoritySubmitted", session.authoritySubmitted)
            put("recordingPath", session.recordingPath ?: "")
            put("wasInRiskZone", session.wasInRiskZone)
            put("wasNighttime", session.wasNighttime)
        }.toString()
    }

    private fun jsonToSession(json: String): EmergencySession {
        val obj = org.json.JSONObject(json)
        return EmergencySession(
            id = obj.getLong("id"),
            triggeredAt = obj.getLong("triggeredAt"),
            triggerSource = com.safeher.ai.data.model.TriggerSource.valueOf(obj.getString("triggerSource")),
            startLatitude = obj.getDouble("startLatitude"),
            startLongitude = obj.getDouble("startLongitude"),
            locationApproximate = obj.getBoolean("locationApproximate"),
            deactivatedAt = obj.getLong("deactivatedAt").takeIf { it != 0L },
            deactivationMethod = obj.getString("deactivationMethod").takeIf { it.isNotEmpty() }
                ?.let { com.safeher.ai.data.model.DeactivationMethod.valueOf(it) },
            durationSeconds = obj.getLong("durationSeconds"),
            classificationResult = obj.getString("classificationResult").takeIf { it.isNotEmpty() }
                ?.let { com.safeher.ai.data.model.ClassificationResult.valueOf(it) },
            classificationScore = obj.getDouble("classificationScore").toFloat(),
            classificationExplanation = obj.getString("classificationExplanation"),
            authoritySubmitted = obj.optBoolean("authoritySubmitted", false),
            recordingPath = obj.getString("recordingPath").takeIf { it.isNotEmpty() },
            wasInRiskZone = obj.getBoolean("wasInRiskZone"),
            wasNighttime = obj.getBoolean("wasNighttime")
        )
    }
}