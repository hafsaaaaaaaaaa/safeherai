// File location: app/src/main/java/com/safeher/ai/data/model/Models.kt

package com.safeher.ai.data.model

// ─────────────────────────────────────────────────────────────
//  EMERGENCY SESSION
// ─────────────────────────────────────────────────────────────

data class EmergencySession(
    val id: Long = 0,
    val triggeredAt: Long = System.currentTimeMillis(),
    val triggerSource: TriggerSource,
    val startLatitude: Double = 0.0,
    val startLongitude: Double = 0.0,
    val locationApproximate: Boolean = false,
    val deactivatedAt: Long? = null,
    val deactivationMethod: DeactivationMethod? = null,
    val durationSeconds: Long = 0,
    val classificationResult: ClassificationResult? = null,
    val classificationScore: Float = 0f,
    val classificationExplanation: String? = null,
    val authoritySubmitted: Boolean = false,
    val recordingPath: String? = null,       // internal path only — never exposed to user
    val wasInRiskZone: Boolean = false,
    val wasNighttime: Boolean = false
)

enum class TriggerSource {
    POWER_BUTTON,
    VOICE_TRIGGER,
    MANUAL           // tapped inside the app — useful for testing
}

enum class DeactivationMethod {
    CALM_PIN,
    FINGERPRINT,
    PHONE_OFFLINE,   // phone went offline — most serious signal
    POWER_LOSS,      // battery died — treated same as offline
    TIMEOUT          // app-level safety timeout
}

enum class ClassificationResult {
    UNSAFE,
    INCONCLUSIVE,
    SAFE,
    UNCLASSIFIED     // model failed to run
}

// ─────────────────────────────────────────────────────────────
//  EMERGENCY CONTACT
// ─────────────────────────────────────────────────────────────

data class EmergencyContact(
    val id: Long = 0,
    val name: String,
    val phone: String,          // E.164 format, e.g. +923001234567
    val hasApp: Boolean = false // if true, notify via FCM; else SMS only
)

// ─────────────────────────────────────────────────────────────
//  USER SETTINGS
// ─────────────────────────────────────────────────────────────

data class UserSettings(
    val userName: String = "",
    val triggerPhrase: String = "",
    val fakeCallerName: String = "Mom",
    val authorityContactPhone: String = "",
    val authorityContactName: String = "",
    val riskAlertsEnabled: Boolean = true,
    val hasCompletedOnboarding: Boolean = false
)

// ─────────────────────────────────────────────────────────────
//  RISK ALERT
// ─────────────────────────────────────────────────────────────

data class RiskAlert(
    val id: Long = 0,
    val timestamp: Long = System.currentTimeMillis(),
    val latitude: Double,
    val longitude: Double,
    val riskScore: Float,
    val zoneName: String = ""
)

// ─────────────────────────────────────────────────────────────
//  TRIGGER EVENT — passed between layers
// ─────────────────────────────────────────────────────────────

sealed class TriggerEvent {
    object PowerButtonDoubleTap : TriggerEvent()
    data class VoicePhrase(val confidence: Float) : TriggerEvent()
    object ManualActivation : TriggerEvent()
}

// ─────────────────────────────────────────────────────────────
//  EMERGENCY STATE — observed by the UI
// ─────────────────────────────────────────────────────────────

sealed class EmergencyState {
    object Idle : EmergencyState()
    data class Active(val session: EmergencySession) : EmergencyState()
    data class Classifying(val session: EmergencySession) : EmergencyState()
    data class Classified(val session: EmergencySession) : EmergencyState()
}