// File location: app/src/main/java/com/safeher/ai/application/SafeHerFirebaseService.kt

package com.safeher.ai.application

import android.app.NotificationManager
import android.util.Log
import androidx.core.app.NotificationCompat
import com.google.firebase.messaging.FirebaseMessagingService
import com.google.firebase.messaging.RemoteMessage
import com.safeher.ai.R
import com.safeher.ai.SafeHerApplication

class SafeHerFirebaseService : FirebaseMessagingService() {

    companion object {
        private const val TAG = "SafeHerFirebaseService"
        var fcmToken: String? = null
            private set
    }

    override fun onNewToken(token: String) {
        super.onNewToken(token)
        fcmToken = token
        Log.d(TAG, "New FCM token: $token")
        getSharedPreferences("safeher_prefs", MODE_PRIVATE)
            .edit()
            .putString("fcm_token", token)
            .apply()
    }

    override fun onMessageReceived(message: RemoteMessage) {
        super.onMessageReceived(message)
        Log.d(TAG, "Message received from: ${message.from}")

        val data = message.data
        val type = data["type"] ?: return

        when (type) {
            "emergency_alert" -> {
                val userName = data["user_name"] ?: "Someone"
                val location = data["location"] ?: "Unknown location"
                showEmergencyNotification(userName, location)
            }
            "safe_alert" -> {
                val userName = data["user_name"] ?: "Someone"
                showSafeNotification(userName)
            }
        }
    }

    private fun showEmergencyNotification(userName: String, location: String) {
        val nm = getSystemService(NotificationManager::class.java)
        val notification = NotificationCompat.Builder(this, SafeHerApplication.CHANNEL_EMERGENCY)
            .setContentTitle("🚨 $userName needs help!")
            .setContentText("Location: $location")
            .setSmallIcon(R.drawable.ic_shield)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true)
            .build()
        nm.notify(System.currentTimeMillis().toInt(), notification)
    }

    private fun showSafeNotification(userName: String) {
        val nm = getSystemService(NotificationManager::class.java)
        val notification = NotificationCompat.Builder(this, SafeHerApplication.CHANNEL_FOREGROUND)
            .setContentTitle("✅ $userName is safe")
            .setContentText("The emergency has ended.")
            .setSmallIcon(R.drawable.ic_shield)
            .setPriority(NotificationCompat.PRIORITY_DEFAULT)
            .setAutoCancel(true)
            .build()
        nm.notify(System.currentTimeMillis().toInt(), notification)
    }
}