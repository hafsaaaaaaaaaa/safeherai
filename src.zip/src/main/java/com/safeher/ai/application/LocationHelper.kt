// File location: app/src/main/java/com/safeher/ai/application/LocationHelper.kt

package com.safeher.ai.application

import android.annotation.SuppressLint
import android.content.Context
import android.location.Location
import com.google.android.gms.location.LocationServices
import kotlinx.coroutines.tasks.await

object LocationHelper {

    @SuppressLint("MissingPermission")
    suspend fun getLastKnownLocation(context: Context): Location? {
        return try {
            LocationServices.getFusedLocationProviderClient(context)
                .lastLocation
                .await()
        } catch (e: Exception) {
            null
        }
    }
}