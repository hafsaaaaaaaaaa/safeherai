// File location: app/src/main/java/com/safeher/ai/application/ContactsHelper.kt

package com.safeher.ai.application

import android.content.Context
import com.safeher.ai.data.model.EmergencyContact
import org.json.JSONArray

object ContactsHelper {

    private const val PREFS_NAME = "safeher_prefs"
    private const val KEY_CONTACTS = "emergency_contacts"

    fun getEmergencyContacts(context: Context): List<EmergencyContact> {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        val json = prefs.getString(KEY_CONTACTS, "[]") ?: "[]"
        return try {
            val array = JSONArray(json)
            (0 until array.length()).map { i ->
                val obj = array.getJSONObject(i)
                EmergencyContact(
                    id = obj.getLong("id"),
                    name = obj.getString("name"),
                    phone = obj.getString("phone")
                )
            }
        } catch (e: Exception) {
            emptyList()
        }
    }

    fun saveEmergencyContacts(context: Context, contacts: List<EmergencyContact>) {
        val array = JSONArray()
        contacts.forEach { contact ->
            val obj = org.json.JSONObject()
            obj.put("id", contact.id)
            obj.put("name", contact.name)
            obj.put("phone", contact.phone)
            array.put(obj)
        }
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .edit()
            .putString(KEY_CONTACTS, array.toString())
            .apply()
    }
}