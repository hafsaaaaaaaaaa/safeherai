// File location: app/src/main/java/com/safeher/ai/application/RiskZoneManager.kt

package com.safeher.ai.application

import android.annotation.SuppressLint
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.location.Location
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.util.Log
import androidx.core.app.NotificationCompat
import com.safeher.ai.R
import com.safeher.ai.SafeHerApplication
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.util.Calendar

class RiskZoneManager(
    private val context: Context,
    private val scope: CoroutineScope
) {

    companion object {
        private const val TAG = "RiskZoneManager"
        private const val ALERT_COOLDOWN_MS = 10 * 60 * 1000L // 10 minutes
        private const val RISK_THRESHOLD = 0.65f
        private const val NOTIFICATION_ID = 2001
    }

    private var monitoringJob: Job? = null
    private var lastAlertTime = 0L
    private var lastAlertLat = 0.0
    private var lastAlertLng = 0.0

    fun startMonitoring() {
        monitoringJob?.cancel()
        monitoringJob = scope.launch(Dispatchers.IO) {
            while (isActive) {
                if (isNighttime()) {
                    checkRiskZone()
                }
                delay(60_000) // check every minute
            }
        }
        Log.d(TAG, "Risk zone monitoring started")
    }

    fun stopMonitoring() {
        monitoringJob?.cancel()
        Log.d(TAG, "Risk zone monitoring stopped")
    }

    @SuppressLint("MissingPermission")
    private suspend fun checkRiskZone() {
        val location = LocationHelper.getLastKnownLocation(context) ?: return
        val riskScore = calculateRiskScore(location)

        if (riskScore >= RISK_THRESHOLD) {
            val now = System.currentTimeMillis()
            val distFromLastAlert = distanceBetween(
                location.latitude, location.longitude,
                lastAlertLat, lastAlertLng
            )

            // Suppress if same zone alerted within cooldown period
            if (now - lastAlertTime < ALERT_COOLDOWN_MS && distFromLastAlert < 200) {
                return
            }

            lastAlertTime = now
            lastAlertLat = location.latitude
            lastAlertLng = location.longitude

            sendRiskAlert(location, riskScore)
        }
    }

    // Rule-based risk scoring until real ML model is integrated
    // In production this would use a trained TFLite geospatial model
    private fun calculateRiskScore(location: Location): Float {
        val hour = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
        val dayOfWeek = Calendar.getInstance().get(Calendar.DAY_OF_WEEK)

        var score = 0.3f // base score

        // Higher risk late at night
        score += when (hour) {
            in 0..3 -> 0.3f   // midnight to 3am — highest risk
            in 3..5 -> 0.2f   // early morning
            in 20..23 -> 0.15f // evening
            else -> 0f
        }

        // Weekend nights slightly higher risk
        if (dayOfWeek == Calendar.FRIDAY || dayOfWeek == Calendar.SATURDAY) {
            score += 0.1f
        }

        // Known high-risk coordinate ranges (placeholder — real app uses crime data)
        // This would be replaced by actual TFLite model inference
        score += getAreaRiskBonus(location.latitude, location.longitude)

        return score.coerceIn(0f, 1f)
    }

    // Placeholder — in production loads from local crime dataset
    private fun getAreaRiskBonus(lat: Double, lng: Double): Float {
        return 0.1f // default moderate bonus
    }

    private fun sendRiskAlert(location: Location, score: Float) {
        // Three short vibrations per SR-F7
        val vibrator = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            val vm = context.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as VibratorManager
            vm.defaultVibrator
        } else {
            @Suppress("DEPRECATION")
            context.getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
        }

        val pattern = longArrayOf(0, 150, 100, 150, 100, 150)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            vibrator.vibrate(VibrationEffect.createWaveform(pattern, -1))
        } else {
            @Suppress("DEPRECATION")
            vibrator.vibrate(pattern, -1)
        }

        // Quiet notification — no text on lock screen per SR-F7
        val nm = context.getSystemService(NotificationManager::class.java)
        val notification = NotificationCompat.Builder(context, SafeHerApplication.CHANNEL_RISK_ALERT)
            .setContentTitle("Heads up")
            .setContentText("Elevated safety activity nearby. Stay aware.")
            .setSmallIcon(R.drawable.ic_shield)
            .setPriority(NotificationCompat.PRIORITY_DEFAULT)
            .setVisibility(NotificationCompat.VISIBILITY_PRIVATE) // hide on lock screen
            .setAutoCancel(true)
            .build()

        nm.notify(NOTIFICATION_ID, notification)
        Log.d(TAG, "Risk alert sent for score=$score at ${location.latitude},${location.longitude}")
    }

    private fun isNighttime(): Boolean {
        val hour = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
        return hour >= 20 || hour < 6
    }

    private fun distanceBetween(lat1: Double, lng1: Double, lat2: Double, lng2: Double): Float {
        val results = FloatArray(1)
        Location.distanceBetween(lat1, lng1, lat2, lng2, results)
        return results[0]
    }
}