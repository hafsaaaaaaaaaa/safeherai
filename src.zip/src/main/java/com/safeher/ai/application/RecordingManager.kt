// File location: app/src/main/java/com/safeher/ai/application/RecordingManager.kt

package com.safeher.ai.application

import android.content.Context
import android.media.MediaRecorder
import android.os.Build
import android.util.Log
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class RecordingManager(private val context: Context) {

    companion object {
        private const val TAG = "RecordingManager"
        private const val CHUNK_DURATION_MS = 60_000L // 60 second chunks per SR-F3
    }

    private var mediaRecorder: MediaRecorder? = null
    private var currentRecordingPath: String? = null
    private var isRecording = false

    // Returns the file path of the recording
    fun startRecording(): String? {
        if (isRecording) {
            Log.w(TAG, "Already recording")
            return currentRecordingPath
        }

        return try {
            val outputFile = createOutputFile()
            currentRecordingPath = outputFile.absolutePath

            mediaRecorder = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                MediaRecorder(context)
            } else {
                @Suppress("DEPRECATION")
                MediaRecorder()
            }

            mediaRecorder?.apply {
                // Audio source — microphone
                setAudioSource(MediaRecorder.AudioSource.MIC)

                // Try video first, fall back to audio only if no camera permission
                try {
                    setVideoSource(MediaRecorder.VideoSource.CAMERA)
                    setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
                    setVideoEncoder(MediaRecorder.VideoEncoder.H264)
                    setVideoSize(1280, 720) // 720p per SR-F3
                    setVideoFrameRate(30)
                } catch (e: Exception) {
                    Log.w(TAG, "Camera not available, audio only: ${e.message}")
                    setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
                }

                setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
                setOutputFile(outputFile.absolutePath)

                prepare()
                start()
            }

            isRecording = true
            Log.d(TAG, "Recording started: ${outputFile.absolutePath}")
            outputFile.absolutePath

        } catch (e: Exception) {
            Log.e(TAG, "Failed to start recording: ${e.message}")
            // Fall back to audio only
            startAudioOnlyRecording()
        }
    }

    private fun startAudioOnlyRecording(): String? {
        return try {
            val outputFile = createOutputFile(audioOnly = true)
            currentRecordingPath = outputFile.absolutePath

            mediaRecorder = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                MediaRecorder(context)
            } else {
                @Suppress("DEPRECATION")
                MediaRecorder()
            }

            mediaRecorder?.apply {
                setAudioSource(MediaRecorder.AudioSource.MIC)
                setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
                setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
                setOutputFile(outputFile.absolutePath)
                prepare()
                start()
            }

            isRecording = true
            Log.d(TAG, "Audio-only recording started: ${outputFile.absolutePath}")
            outputFile.absolutePath

        } catch (e: Exception) {
            Log.e(TAG, "Audio recording also failed: ${e.message}")
            null
        }
    }

    fun stopRecording(): String? {
        if (!isRecording) return null

        return try {
            mediaRecorder?.apply {
                stop()
                release()
            }
            mediaRecorder = null
            isRecording = false
            Log.d(TAG, "Recording stopped: $currentRecordingPath")
            currentRecordingPath
        } catch (e: Exception) {
            Log.e(TAG, "Error stopping recording: ${e.message}")
            mediaRecorder?.release()
            mediaRecorder = null
            isRecording = false
            currentRecordingPath
        }
    }

    fun isRecording() = isRecording

    // Creates file in private app directory — not accessible by other apps
    // This implements SR-F3: private encrypted storage
    private fun createOutputFile(audioOnly: Boolean = false): File {
        val timestamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(Date())
        val extension = if (audioOnly) "m4a" else "mp4"
        val fileName = "safeher_${timestamp}.$extension"

        // Use app's private files directory — no other app can access this
        val dir = File(context.filesDir, "recordings").also { it.mkdirs() }
        return File(dir, fileName)
    }

    // Delete a recording file — called after 72 hours for non-unsafe incidents
    fun deleteRecording(path: String) {
        try {
            val file = File(path)
            if (file.exists()) {
                file.delete()
                Log.d(TAG, "Recording deleted: $path")
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error deleting recording: ${e.message}")
        }
    }

    // Get all recordings (for internal use only — never exposed to user)
    fun getAllRecordings(): List<File> {
        val dir = File(context.filesDir, "recordings")
        return dir.listFiles()?.toList() ?: emptyList()
    }

    fun cleanup() {
        if (isRecording) stopRecording()
    }
}