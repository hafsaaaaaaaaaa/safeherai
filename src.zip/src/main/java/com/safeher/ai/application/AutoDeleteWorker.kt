// File location: app/src/main/java/com/safeher/ai/application/AutoDeleteWorker.kt

package com.safeher.ai.application

import android.content.Context
import android.util.Log
import androidx.work.CoroutineWorker
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import com.safeher.ai.data.IncidentRepository
import java.util.concurrent.TimeUnit

class AutoDeleteWorker(
    context: Context,
    params: WorkerParameters
) : CoroutineWorker(context, params) {

    companion object {
        private const val TAG = "AutoDeleteWorker"
        private const val WORK_NAME = "safeher_auto_delete"

        fun schedule(context: Context) {
            val request = PeriodicWorkRequestBuilder<AutoDeleteWorker>(
                6, TimeUnit.HOURS // check every 6 hours
            ).build()

            WorkManager.getInstance(context).enqueueUniquePeriodicWork(
                WORK_NAME,
                ExistingPeriodicWorkPolicy.KEEP,
                request
            )
            Log.d(TAG, "Auto-delete worker scheduled")
        }
    }

    override suspend fun doWork(): Result {
        return try {
            val repository = IncidentRepository(applicationContext)

            // Delete recordings for expired incidents
            val incidents = repository.getAllIncidents()
            val now = System.currentTimeMillis()
            val cutoff = now - (72 * 60 * 60 * 1000L) // 72 hours

            val recordingManager = RecordingManager(applicationContext)
            incidents.forEach { incident ->
                val isExpired = incident.triggeredAt < cutoff
                val isNotUnsafe = incident.classificationResult?.name != "UNSAFE"
                if (isExpired && isNotUnsafe && incident.recordingPath != null) {
                    recordingManager.deleteRecording(incident.recordingPath)
                    Log.d(TAG, "Deleted expired recording: ${incident.recordingPath}")
                }
            }

            // Clean up expired incident records
            repository.deleteExpiredIncidents()

            Log.d(TAG, "Auto-delete complete")
            Result.success()
        } catch (e: Exception) {
            Log.e(TAG, "Auto-delete failed: ${e.message}")
            Result.retry()
        }
    }
}