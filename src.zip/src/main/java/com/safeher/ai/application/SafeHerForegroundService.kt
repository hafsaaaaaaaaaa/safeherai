// File location: app/src/main/java/com/safeher/ai/application/SafeHerForegroundService.kt

package com.safeher.ai.application

import android.app.Notification
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.os.IBinder
import android.os.PowerManager
import androidx.core.app.NotificationCompat
import com.safeher.ai.R
import com.safeher.ai.SafeHerApplication
import com.safeher.ai.data.model.TriggerEvent
import com.safeher.ai.presentation.MainActivity
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch

class SafeHerForegroundService : Service() {

    companion object {
        const val ACTION_START = "com.safeher.ai.START"
        const val ACTION_STOP = "com.safeher.ai.STOP"
        const val ACTION_TRIGGER_EMERGENCY = "com.safeher.ai.TRIGGER_EMERGENCY"
        const val NOTIFICATION_ID = 1001

        var isRunning = false
            private set

        var instance: SafeHerForegroundService? = null
            private set
    }

    private val serviceJob = SupervisorJob()
    private val serviceScope = CoroutineScope(Dispatchers.Main + serviceJob)

    private lateinit var emergencyManager: EmergencyManager
    private lateinit var powerButtonDetector: PowerButtonDetector
    private lateinit var riskZoneManager: RiskZoneManager
    private lateinit var voiceTriggerManager: VoiceTriggerManager
    private var wakeLock: PowerManager.WakeLock? = null

    override fun onCreate() {
        super.onCreate()
        isRunning = true
        instance = this

        emergencyManager = EmergencyManager.getInstance(this)
        riskZoneManager = RiskZoneManager(this, serviceScope)

        powerButtonDetector = PowerButtonDetector(this) {
            serviceScope.launch {
                emergencyManager.onTrigger(TriggerEvent.PowerButtonDoubleTap)
            }
        }

        voiceTriggerManager = VoiceTriggerManager(
            context = this,
            scope = serviceScope,
            onTriggerDetected = { confidence ->
                serviceScope.launch {
                    emergencyManager.onTrigger(TriggerEvent.VoicePhrase(confidence))
                }
            }
        )

        val pm = getSystemService(POWER_SERVICE) as PowerManager
        wakeLock = pm.newWakeLock(
            PowerManager.PARTIAL_WAKE_LOCK,
            "SafeHer::ServiceWakeLock"
        ).apply { acquire(10 * 60 * 1000L) }

        AutoDeleteWorker.schedule(this)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START -> {
                startForeground(NOTIFICATION_ID, buildNotification())
                powerButtonDetector.start()
                riskZoneManager.startMonitoring()
                voiceTriggerManager.start()
            }
            ACTION_STOP -> {
                powerButtonDetector.stop()
                riskZoneManager.stopMonitoring()
                voiceTriggerManager.stop()
                stopSelf()
            }
            ACTION_TRIGGER_EMERGENCY -> {
                serviceScope.launch {
                    emergencyManager.onTrigger(TriggerEvent.PowerButtonDoubleTap)
                }
            }
        }
        return START_STICKY
    }

    fun pauseVoiceTrigger() = voiceTriggerManager.stop()
    fun resumeVoiceTrigger() = voiceTriggerManager.start()

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        super.onDestroy()
        isRunning = false
        instance = null
        powerButtonDetector.stop()
        riskZoneManager.stopMonitoring()
        voiceTriggerManager.stop()
        serviceScope.cancel()
        wakeLock?.release()
        emergencyManager.cleanup()
    }

    // Fixed: notification now opens MainActivity when tapped
    fun buildNotification(): Notification {
        val openAppIntent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val pendingIntent = PendingIntent.getActivity(
            this, 0, openAppIntent,
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        return NotificationCompat.Builder(this, SafeHerApplication.CHANNEL_FOREGROUND)
            .setContentTitle("SafeHer is active")
            .setContentText("Double-press power button or say your phrase to trigger emergency.")
            .setSmallIcon(R.drawable.ic_shield)
            .setOngoing(true)
            .setShowWhen(false)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setContentIntent(pendingIntent)
            .build()
    }

    fun updateNotificationForEmergency() {
        val openAppIntent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val pendingIntent = PendingIntent.getActivity(
            this, 1, openAppIntent,
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        val nm = getSystemService(NOTIFICATION_SERVICE) as android.app.NotificationManager
        val notification = NotificationCompat.Builder(this, SafeHerApplication.CHANNEL_EMERGENCY)
            .setContentTitle("🚨 Emergency Active")
            .setContentText("Recording and sharing location. Tap to open.")
            .setSmallIcon(R.drawable.ic_shield)
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setContentIntent(pendingIntent)
            .build()
        nm.notify(NOTIFICATION_ID, notification)
    }

    fun updateNotificationForIdle() {
        val nm = getSystemService(NOTIFICATION_SERVICE) as android.app.NotificationManager
        nm.notify(NOTIFICATION_ID, buildNotification())
    }
}