// File location: app/src/main/java/com/safeher/ai/application/EmergencyManager.kt

package com.safeher.ai.application

import android.content.Context
import android.content.SharedPreferences
import android.telephony.SmsManager
import android.util.Log
import com.safeher.ai.data.IncidentRepository
import com.safeher.ai.data.model.DeactivationMethod
import com.safeher.ai.data.model.EmergencySession
import com.safeher.ai.data.model.EmergencyState
import com.safeher.ai.data.model.TriggerEvent
import com.safeher.ai.data.model.TriggerSource
import com.safeher.ai.domain.SituationClassifier
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class EmergencyManager private constructor(private val context: Context) {

    companion object {
        private const val TAG = "EmergencyManager"
        private const val PREFS_NAME = "safeher_prefs"
        private const val KEY_USER_NAME = "user_name"

        @Volatile
        private var instance: EmergencyManager? = null

        fun getInstance(context: Context): EmergencyManager {
            return instance ?: synchronized(this) {
                instance ?: EmergencyManager(context.applicationContext).also {
                    instance = it
                }
            }
        }

        val _state = MutableStateFlow<EmergencyState>(EmergencyState.Idle)
        val state: StateFlow<EmergencyState> = _state
    }

    private val scope = CoroutineScope(Dispatchers.Main + SupervisorJob())
    private var locationJob: Job? = null
    private var currentSession: EmergencySession? = null
    private val prefs: SharedPreferences =
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
    private val recordingManager = RecordingManager(context)
    private val repository = IncidentRepository(context)
    private val classifier = SituationClassifier()

    suspend fun onTrigger(event: TriggerEvent) {
        if (_state.value is EmergencyState.Active) {
            Log.d(TAG, "Trigger ignored — already active")
            return
        }

        val source = when (event) {
            is TriggerEvent.PowerButtonDoubleTap -> TriggerSource.POWER_BUTTON
            is TriggerEvent.VoicePhrase -> TriggerSource.VOICE_TRIGGER
            is TriggerEvent.ManualActivation -> TriggerSource.MANUAL
        }

        // Pause voice trigger to avoid mic noise during recording
        SafeHerForegroundService.instance?.pauseVoiceTrigger()

        val recordingPath = withContext(Dispatchers.IO) {
            recordingManager.startRecording()
        }

        val location = withContext(Dispatchers.IO) {
            LocationHelper.getLastKnownLocation(context)
        }

        val session = EmergencySession(
            triggeredAt = System.currentTimeMillis(),
            triggerSource = source,
            startLatitude = location?.latitude ?: 0.0,
            startLongitude = location?.longitude ?: 0.0,
            locationApproximate = location == null,
            recordingPath = recordingPath,
            wasNighttime = isNighttime()
        )

        val savedId = repository.saveIncident(session)
        val savedSession = session.copy(id = savedId)

        currentSession = savedSession
        _state.value = EmergencyState.Active(savedSession)

        SafeHerForegroundService.instance?.updateNotificationForEmergency()
        startLocationLoop(savedSession)
        notifyContacts(savedSession)

        Log.d(TAG, "Emergency started: source=$source id=$savedId")
    }

    private fun startLocationLoop(session: EmergencySession) {
        locationJob?.cancel()
        locationJob = scope.launch(Dispatchers.IO) {
            while (isActive) {
                try {
                    val location = LocationHelper.getLastKnownLocation(context)
                    if (location != null) {
                        Log.d(TAG, "Location: ${location.latitude}, ${location.longitude}")
                    }
                } catch (e: Exception) {
                    Log.e(TAG, "Location error: ${e.message}")
                }
                delay(15_000)
            }
        }
    }

    private suspend fun notifyContacts(session: EmergencySession) {
        withContext(Dispatchers.IO) {
            val userName = prefs.getString(KEY_USER_NAME, "SafeHer User") ?: "SafeHer User"
            val contacts = ContactsHelper.getEmergencyContacts(context)
            if (contacts.isEmpty()) return@withContext

            val mapsLink = if (session.startLatitude != 0.0)
                "https://maps.google.com/?q=${session.startLatitude},${session.startLongitude}"
            else "Location unavailable"

            val message = "🚨 ALERT: $userName needs help! Live location: $mapsLink"
            contacts.forEach { contact ->
                try { sendSms(contact.phone, message) }
                catch (e: Exception) { Log.e(TAG, "SMS failed: ${e.message}") }
            }
        }
    }

    // Per UC-05 alternate flow 4a — notify contacts of failed deactivation attempt
    fun notifyFailedDeactivation() {
        scope.launch(Dispatchers.IO) {
            val userName = prefs.getString(KEY_USER_NAME, "SafeHer User") ?: "SafeHer User"
            val contacts = ContactsHelper.getEmergencyContacts(context)
            val message = "⚠️ WARNING: Failed deactivation attempt detected for $userName. Emergency still active."
            contacts.forEach { contact ->
                try { sendSms(contact.phone, message) }
                catch (e: Exception) { Log.e(TAG, "Failed deactivation SMS error: ${e.message}") }
            }
        }
    }

    private fun sendSms(phone: String, message: String) {
        try {
            val smsManager = context.getSystemService(SmsManager::class.java)
            smsManager.sendTextMessage(phone, null, message, null, null)
        } catch (e: Exception) {
            Log.e(TAG, "SMS error: ${e.message}")
        }
    }

    suspend fun deactivate(method: DeactivationMethod) {
        val session = currentSession ?: return
        locationJob?.cancel()

        val recordingPath = withContext(Dispatchers.IO) {
            recordingManager.stopRecording()
        }

        val endTime = System.currentTimeMillis()
        val duration = (endTime - session.triggeredAt) / 1000

        val completedSession = session.copy(
            deactivatedAt = endTime,
            deactivationMethod = method,
            durationSeconds = duration,
            recordingPath = recordingPath
        )

        // Resume voice trigger
        SafeHerForegroundService.instance?.resumeVoiceTrigger()

        currentSession = null

        // Reset to idle immediately — fixes Bug 2
        _state.value = EmergencyState.Idle

        notifySafe(completedSession)
        SafeHerForegroundService.instance?.updateNotificationForIdle()

        // Run classification in background
        runClassification(completedSession)

        Log.d(TAG, "Emergency deactivated via $method after ${duration}s")
    }

    private suspend fun runClassification(session: EmergencySession) {
        withContext(Dispatchers.IO) {
            try {
                val output = classifier.classify(session)
                repository.updateClassification(
                    session.id,
                    output.result,
                    output.score,
                    output.explanation
                )
                val classifiedSession = session.copy(
                    classificationResult = output.result,
                    classificationScore = output.score,
                    classificationExplanation = output.explanation
                )
                _state.value = EmergencyState.Classified(classifiedSession)
                Log.d(TAG, "Classification: ${output.result}")
            } catch (e: Exception) {
                Log.e(TAG, "Classification failed: ${e.message}")
            }
        }
    }

    private suspend fun notifySafe(session: EmergencySession) {
        withContext(Dispatchers.IO) {
            val userName = prefs.getString(KEY_USER_NAME, "SafeHer User") ?: "SafeHer User"
            val contacts = ContactsHelper.getEmergencyContacts(context)
            val message = "✅ $userName is safe. Emergency has ended."
            contacts.forEach { contact ->
                try { sendSms(contact.phone, message) }
                catch (e: Exception) { Log.e(TAG, "Safe SMS failed: ${e.message}") }
            }
        }
    }

    private fun isNighttime(): Boolean {
        val hour = java.util.Calendar.getInstance().get(java.util.Calendar.HOUR_OF_DAY)
        return hour >= 20 || hour < 6
    }

    fun cleanup() {
        locationJob?.cancel()
        recordingManager.cleanup()
    }
}