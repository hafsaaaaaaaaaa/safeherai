// File location: app/src/main/java/com/safeher/ai/application/PowerButtonDetector.kt

package com.safeher.ai.application

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.util.Log

class PowerButtonDetector(
    private val context: Context,
    private val onDoubleTap: () -> Unit
) {

    companion object {
        private const val TAG = "PowerButtonDetector"
        private const val DOUBLE_PRESS_WINDOW_MS = 500L // must press twice within 500ms
    }

    private var lastPressTime = 0L
    private var isRegistered = false

    private val receiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            when (intent.action) {
                Intent.ACTION_SCREEN_OFF -> {
                    val now = System.currentTimeMillis()
                    val timeSinceLast = now - lastPressTime

                    Log.d(TAG, "Screen off detected. Time since last: ${timeSinceLast}ms")

                    if (timeSinceLast <= DOUBLE_PRESS_WINDOW_MS && lastPressTime != 0L) {
                        Log.d(TAG, "Double tap detected! Firing emergency trigger.")
                        onDoubleTap()
                        lastPressTime = 0L // reset so it doesn't triple-fire
                    } else {
                        lastPressTime = now
                    }
                }
                Intent.ACTION_SCREEN_ON -> {
                    // Screen turning on resets the counter
                    // This prevents accidental triggers when waking the phone
                    val now = System.currentTimeMillis()
                    val timeSinceLast = now - lastPressTime

                    // If screen turned back on very quickly after turning off,
                    // it was a single press to wake — reset the counter
                    if (timeSinceLast < DOUBLE_PRESS_WINDOW_MS) {
                        lastPressTime = now
                    }
                }
            }
        }
    }

    fun start() {
        if (isRegistered) return
        val filter = IntentFilter().apply {
            addAction(Intent.ACTION_SCREEN_OFF)
            addAction(Intent.ACTION_SCREEN_ON)
        }
        context.registerReceiver(receiver, filter)
        isRegistered = true
        Log.d(TAG, "PowerButtonDetector started")
    }

    fun stop() {
        if (!isRegistered) return
        try {
            context.unregisterReceiver(receiver)
        } catch (e: Exception) {
            Log.e(TAG, "Error unregistering receiver: ${e.message}")
        }
        isRegistered = false
        Log.d(TAG, "PowerButtonDetector stopped")
    }
}