// File location: app/src/main/java/com/safeher/ai/application/SafeHerAccessibilityService.kt

package com.safeher.ai.application

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.AccessibilityServiceInfo
import android.content.Intent
import android.util.Log
import android.view.KeyEvent
import android.view.accessibility.AccessibilityEvent
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch

class SafeHerAccessibilityService : AccessibilityService() {

    companion object {
        private const val TAG = "SafeHerAccessibility"
        private const val DOUBLE_PRESS_WINDOW_MS = 500L
        var isEnabled = false
            private set
    }

    private val scope = CoroutineScope(Dispatchers.Main + SupervisorJob())
    private var lastPressTime = 0L

    override fun onServiceConnected() {
        super.onServiceConnected()
        isEnabled = true
        Log.d(TAG, "Accessibility service connected")

        serviceInfo = serviceInfo.apply {
            flags = flags or AccessibilityServiceInfo.FLAG_REQUEST_FILTER_KEY_EVENTS
        }
    }

    override fun onKeyEvent(event: KeyEvent): Boolean {
        if (event.keyCode == KeyEvent.KEYCODE_POWER &&
            event.action == KeyEvent.ACTION_DOWN) {

            val now = System.currentTimeMillis()
            val timeSinceLast = now - lastPressTime

            if (timeSinceLast <= DOUBLE_PRESS_WINDOW_MS && lastPressTime != 0L) {
                Log.d(TAG, "Double press detected via AccessibilityService!")
                triggerEmergency()
                lastPressTime = 0L
                return true // consume the event
            } else {
                lastPressTime = now
            }
        }
        return false
    }

    private fun triggerEmergency() {
        scope.launch {
            val emergencyManager = EmergencyManager.getInstance(applicationContext)
            emergencyManager.onTrigger(com.safeher.ai.data.model.TriggerEvent.PowerButtonDoubleTap)
        }
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {
        isEnabled = false
    }

    override fun onDestroy() {
        super.onDestroy()
        isEnabled = false
    }
}