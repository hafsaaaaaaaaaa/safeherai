// File location: app/src/main/java/com/safeher/ai/application/VoiceTriggerManager.kt

package com.safeher.ai.application

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.util.Log
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

class VoiceTriggerManager(
    private val context: Context,
    private val scope: CoroutineScope,
    private val onTriggerDetected: (confidence: Float) -> Unit
) {

    companion object {
        private const val TAG = "VoiceTriggerManager"
        private const val MIN_CONFIDENCE = 0.70f
        private const val AUTO_CONFIRM_CONFIDENCE = 0.85f
        private const val PREFS_NAME = "safeher_prefs"
        private const val KEY_TRIGGER_PHRASE = "trigger_phrase"
    }

    private var speechRecognizer: SpeechRecognizer? = null
    private var isListening = false
    private var pendingConfirmation = false
    private var restartJob: kotlinx.coroutines.Job? = null

    fun start() {
        if (!SpeechRecognizer.isRecognitionAvailable(context)) {
            Log.w(TAG, "Speech recognition not available on this device")
            return
        }
        isListening = true
        startListening()
        Log.d(TAG, "Voice trigger started")
    }

    fun stop() {
        isListening = false
        restartJob?.cancel()
        speechRecognizer?.destroy()
        speechRecognizer = null
        Log.d(TAG, "Voice trigger stopped")
    }

    private fun getTriggerPhrase(): String {
        return context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .getString(KEY_TRIGGER_PHRASE, "") ?: ""
    }

    private fun startListening() {
        if (!isListening) return

        val triggerPhrase = getTriggerPhrase()
        if (triggerPhrase.isEmpty()) {
            Log.w(TAG, "No trigger phrase set — voice trigger inactive")
            return
        }

        speechRecognizer?.destroy()
        speechRecognizer = SpeechRecognizer.createSpeechRecognizer(context)

        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 5)
            putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, context.packageName)
        }

        speechRecognizer?.setRecognitionListener(object : RecognitionListener {
            override fun onResults(results: Bundle?) {
                val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                val scores = results?.getFloatArray(SpeechRecognizer.CONFIDENCE_SCORES)

                if (matches != null && scores != null) {
                    for (i in matches.indices) {
                        val text = matches[i].lowercase().trim()
                        val confidence = if (i < scores.size) scores[i] else 0f

                        Log.d(TAG, "Heard: '$text' (confidence=$confidence)")

                        if (phraseMatches(text, triggerPhrase)) {
                            handleMatch(confidence)
                            return
                        }
                    }
                }
                // Restart listening after processing
                scheduleRestart()
            }

            override fun onError(error: Int) {
                Log.d(TAG, "Recognition error: $error")
                scheduleRestart()
            }

            override fun onReadyForSpeech(params: Bundle?) {}
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onPartialResults(partialResults: Bundle?) {}
            override fun onEvent(eventType: Int, params: Bundle?) {}
        })

        speechRecognizer?.startListening(intent)
    }

    private fun phraseMatches(heard: String, trigger: String): Boolean {
        val triggerLower = trigger.lowercase().trim()
        // Check if heard contains the trigger phrase
        return heard.contains(triggerLower) ||
                similarity(heard, triggerLower) > 0.75f
    }

    // Simple similarity check for partial phrase matches
    private fun similarity(s1: String, s2: String): Float {
        if (s1 == s2) return 1f
        if (s1.isEmpty() || s2.isEmpty()) return 0f
        val longer = if (s1.length > s2.length) s1 else s2
        val shorter = if (s1.length > s2.length) s2 else s1
        val matchingChars = shorter.count { longer.contains(it) }
        return matchingChars.toFloat() / longer.length
    }

    private fun handleMatch(confidence: Float) {
        when {
            confidence >= AUTO_CONFIRM_CONFIDENCE -> {
                // High confidence — trigger immediately per SR-F2
                Log.d(TAG, "High confidence match ($confidence) — triggering emergency")
                pendingConfirmation = false
                onTriggerDetected(confidence)
            }
            confidence >= MIN_CONFIDENCE -> {
                if (pendingConfirmation) {
                    // Second utterance confirmed — trigger
                    Log.d(TAG, "Second utterance confirmed — triggering emergency")
                    pendingConfirmation = false
                    onTriggerDetected(confidence)
                } else {
                    // First utterance at medium confidence — wait for second
                    Log.d(TAG, "Medium confidence ($confidence) — waiting for confirmation")
                    pendingConfirmation = true
                    // Auto-cancel pending confirmation after 5 seconds per UC-02
                    scope.launch {
                        delay(5000)
                        pendingConfirmation = false
                    }
                    scheduleRestart(delayMs = 500)
                }
            }
            else -> {
                pendingConfirmation = false
                scheduleRestart()
            }
        }
    }

    private fun scheduleRestart(delayMs: Long = 1000) {
        if (!isListening) return
        restartJob?.cancel()
        restartJob = scope.launch(Dispatchers.Main) {
            delay(delayMs)
            if (isActive && isListening) {
                startListening()
            }
        }
    }
}