// File location: app/src/main/java/com/safeher/ai/domain/SituationClassifier.kt

package com.safeher.ai.domain

import android.util.Log
import com.safeher.ai.data.model.ClassificationResult
import com.safeher.ai.data.model.DeactivationMethod
import com.safeher.ai.data.model.EmergencySession

data class ClassificationOutput(
    val result: ClassificationResult,
    val score: Float,
    val explanation: String
)

class SituationClassifier {

    companion object {
        private const val TAG = "SituationClassifier"

        // Weights per SR-F8
        private const val WEIGHT_AUDIO = 0.40f
        private const val WEIGHT_DURATION = 0.20f
        private const val WEIGHT_DEACTIVATION = 0.25f
        private const val WEIGHT_LOCATION = 0.15f

        // Thresholds
        private const val THRESHOLD_UNSAFE = 0.70f
        private const val THRESHOLD_INCONCLUSIVE = 0.40f
    }

    fun classify(session: EmergencySession): ClassificationOutput {
        Log.d(TAG, "Classifying incident ${session.id}")

        // Signal 1: Audio score
        // Without a real ML model we use duration and context as proxy
        // In production this would run TFLite audio classifier on the recording
        val audioScore = estimateAudioScore(session)

        // Signal 2: Duration weight per SR-F8
        val durationWeight = when {
            session.durationSeconds < 30 -> 0.3f   // likely accidental
            session.durationSeconds < 120 -> 0.6f  // ambiguous
            else -> 0.9f                            // sustained — more serious
        }

        // Signal 3: Deactivation method per SR-F8
        val deactivationScore = when (session.deactivationMethod) {
            DeactivationMethod.CALM_PIN -> 0.2f        // user reached safety normally
            DeactivationMethod.FINGERPRINT -> 0.3f
            DeactivationMethod.PHONE_OFFLINE -> 0.9f   // most serious — phone taken/lost
            DeactivationMethod.POWER_LOSS -> 0.9f
            DeactivationMethod.TIMEOUT -> 0.7f
            null -> 0.5f                               // unknown — treat as moderate
        }

        // Signal 4: Location context per SR-F8
        val locationScore = if (session.wasInRiskZone && session.wasNighttime) 0.8f else 0.3f

        // Weighted combination
        val combinedScore = (audioScore * WEIGHT_AUDIO) +
                (durationWeight * WEIGHT_DURATION) +
                (deactivationScore * WEIGHT_DEACTIVATION) +
                (locationScore * WEIGHT_LOCATION)

        val result = when {
            combinedScore >= THRESHOLD_UNSAFE -> ClassificationResult.UNSAFE
            combinedScore >= THRESHOLD_INCONCLUSIVE -> ClassificationResult.INCONCLUSIVE
            else -> ClassificationResult.SAFE
        }

        val explanation = buildExplanation(
            result, session, audioScore, durationWeight, deactivationScore, locationScore
        )

        Log.d(TAG, "Classification: $result (score=$combinedScore)")
        return ClassificationOutput(result, combinedScore, explanation)
    }

    // Proxy audio scoring until real TFLite model is integrated
    // Uses deactivation and duration as signals
    private fun estimateAudioScore(session: EmergencySession): Float {
        return when {
            session.deactivationMethod == DeactivationMethod.PHONE_OFFLINE -> 0.85f
            session.deactivationMethod == DeactivationMethod.POWER_LOSS -> 0.85f
            session.durationSeconds > 300 -> 0.75f  // 5+ minutes — high concern
            session.durationSeconds > 120 -> 0.55f
            session.durationSeconds < 15 -> 0.15f   // very short — likely accidental
            else -> 0.40f
        }
    }

    // Builds plain language explanation per SR-NF9 and UR-NF4
    private fun buildExplanation(
        result: ClassificationResult,
        session: EmergencySession,
        audioScore: Float,
        durationWeight: Float,
        deactivationScore: Float,
        locationScore: Float
    ): String {
        val parts = mutableListOf<String>()

        // Duration signal
        when {
            session.durationSeconds < 30 ->
                parts.add("the emergency lasted under 30 seconds, which suggests it may have been accidental")
            session.durationSeconds > 300 ->
                parts.add("the emergency lasted over 5 minutes, which is a strong concern signal")
            else ->
                parts.add("the emergency lasted ${session.durationSeconds} seconds")
        }

        // Deactivation signal
        when (session.deactivationMethod) {
            DeactivationMethod.CALM_PIN ->
                parts.add("it ended with a calm PIN entry, suggesting you reached safety normally")
            DeactivationMethod.PHONE_OFFLINE, DeactivationMethod.POWER_LOSS ->
                parts.add("the phone went offline or lost power, which is a serious concern")
            DeactivationMethod.TIMEOUT ->
                parts.add("the emergency timed out without a normal deactivation")
            else -> {}
        }

        // Location signal
        if (session.wasInRiskZone && session.wasNighttime) {
            parts.add("this occurred in a flagged risk zone at night")
        }

        val intro = when (result) {
            ClassificationResult.UNSAFE ->
                "This incident has been classified as UNSAFE. "
            ClassificationResult.INCONCLUSIVE ->
                "This incident is INCONCLUSIVE. "
            ClassificationResult.SAFE ->
                "This incident appears to have been SAFE or accidental. "
            ClassificationResult.UNCLASSIFIED ->
                "This incident could not be classified. "
        }

        val body = if (parts.isEmpty()) {
            "Not enough signals to provide a detailed explanation."
        } else {
            "Specifically: ${parts.joinToString("; ")}."
        }

        val footer = when (result) {
            ClassificationResult.UNSAFE ->
                " You can submit this incident to your authority contact."
            ClassificationResult.INCONCLUSIVE ->
                " The recording will be kept for 72 hours. If you believe this was unsafe, you can flag it for review."
            ClassificationResult.SAFE ->
                " The recording will be automatically deleted after 72 hours."
            else -> ""
        }

        return intro + body + footer
    }
}